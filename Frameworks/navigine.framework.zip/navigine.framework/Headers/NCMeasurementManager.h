#import <Foundation/Foundation.h>
@protocol NCMeasurementListener;


@interface NCMeasurementManager : NSObject

- (void)addMeasurementListener:(nullable id<NCMeasurementListener>)listener;

- (void)removeMeasurementListener:(nullable id<NCMeasurementListener>)listener;

@end
