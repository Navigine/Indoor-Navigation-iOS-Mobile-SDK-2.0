#import <Foundation/Foundation.h>


@protocol NCInspectListener

- (void)onLocationUploaded;

- (void)onUploadProgress:(int32_t)received
                   total:(int32_t)total;

- (void)onTransmitterChanged;

- (void)onInspectError:(nullable NSError *)error;

@end
