#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class NCCircleMapObject;
@class NCLineMapObject;
@class NCTextureMapObject;
@class NCPoint;
@class NCSublocation;

@interface NCLocationView : UIView

- (instancetype)initWithFrame:(CGRect)frame;

- (NCCircleMapObject *) createCircleMapObject;

- (void)addCircleMapObject: (NCCircleMapObject *)mapObject;

- (nullable NCCircleMapObject *) getCircleMapObjectAt: (NCPoint *)point;

- (NCLineMapObject *) createLineMapObject;

- (void)addLineMapObject: (NCLineMapObject *)mapObject;

- (NCTextureMapObject *) createTextureMapObject;

- (NCPoint *) screenToMetricCoordinates: (NCPoint *) point;

- (void) addTextureMapObject: (NCTextureMapObject *)mapObject;

- (void) setSublocation: (int) sublocationId;

- (void) setTargetPoint: (NCPoint *) point;

- (void) showBeacons: (bool) visibility;

- (void) showEddystones: (bool) visibility;

- (void) showWifis: (bool) visibility;

- (void) showVenues: (bool) visibility;

#pragma mark Gesture Recognizers

/**
 Replaces the tap gesture recognizer used by the map view and adds it to the UIView.
 */
@property (strong, nonatomic) UITapGestureRecognizer* tapGestureRecognizer;

/**
 Replaces the double tap gesture recognizer used by the map view and adds it to the UIView.
 */
@property (strong, nonatomic) UITapGestureRecognizer* doubleTapGestureRecognizer;

/**
 Replaces the pan gesture recognizer used by the map view and adds it to the UIView.
 */
@property (strong, nonatomic) UIPanGestureRecognizer* panGestureRecognizer;

/**
 Replaces the pinch gesture recognizer used by the map view and adds it to the UIView.
 */
@property (strong, nonatomic) UIPinchGestureRecognizer* pinchGestureRecognizer;

/**
 Replaces the long press gesture recognizer used by the map view and adds it to the UIView.
 */
@property (strong, nonatomic) UILongPressGestureRecognizer* longPressGestureRecognizer;


@end

NS_ASSUME_NONNULL_END
