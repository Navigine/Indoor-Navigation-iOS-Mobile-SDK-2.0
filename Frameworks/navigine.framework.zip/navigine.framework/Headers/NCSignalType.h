#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, NCSignalType)
{
    NCSignalTypeWIFI,
    NCSignalTypeBEACON,
    NCSignalTypeBLUETOOTH,
    NCSignalTypeEDDYSTONE,
    NCSignalTypeWIFIRTT,
};
