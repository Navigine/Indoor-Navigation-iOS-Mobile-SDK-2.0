#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, NCReferenceEntryType)
{
    NCReferenceEntryTypeBEACON,
    NCReferenceEntryTypeWIFI,
    NCReferenceEntryTypeBLE,
    NCReferenceEntryTypeEDDYSTONE,
    NCReferenceEntryTypeMAGNET,
};
