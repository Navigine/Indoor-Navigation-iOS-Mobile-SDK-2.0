#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, NCSensorType)
{
    NCSensorTypeACCELEROMETER,
    NCSensorTypeMAGNETOMETER,
    NCSensorTypeGYROSCOPE,
    NCSensorTypeBAROMETER,
    NCSensorTypeLOCATION,
    NCSensorTypeORIENTATION,
};
