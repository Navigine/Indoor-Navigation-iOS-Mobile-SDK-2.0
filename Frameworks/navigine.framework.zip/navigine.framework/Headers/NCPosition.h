#import "NCPoint.h"
#import <Foundation/Foundation.h>
@class NCRoutePath;
@class NCZone;

@interface NCPosition : NSObject
- (nonnull instancetype)initWithPoint:(nonnull NCPoint *)point
                           locationId:(int32_t)locationId
                        sublocationId:(int32_t)sublocationId
                                   id:(nonnull NSString *)id
                                 time:(nonnull NSDate *)time
                             accuracy:(float)accuracy
                              azimuth:(float)azimuth
                                paths:(nonnull NSArray<NCRoutePath *> *)paths
                                zones:(nonnull NSArray<NCZone *> *)zones;
+ (nonnull instancetype)positionWithPoint:(nonnull NCPoint *)point
                               locationId:(int32_t)locationId
                            sublocationId:(int32_t)sublocationId
                                       id:(nonnull NSString *)id
                                     time:(nonnull NSDate *)time
                                 accuracy:(float)accuracy
                                  azimuth:(float)azimuth
                                    paths:(nonnull NSArray<NCRoutePath *> *)paths
                                    zones:(nonnull NSArray<NCZone *> *)zones;

@property (nonatomic, readonly, nonnull) NCPoint * point;

@property (nonatomic, readonly) int32_t locationId;

@property (nonatomic, readonly) int32_t sublocationId;

@property (nonatomic, readonly, nonnull) NSString * id;

@property (nonatomic, readonly, nonnull) NSDate * time;

@property (nonatomic, readonly) float accuracy;

@property (nonatomic, readonly) float azimuth;

@property (nonatomic, readonly, nonnull) NSArray<NCRoutePath *> * paths;

@property (nonatomic, readonly, nonnull) NSArray<NCZone *> * zones;

@end
